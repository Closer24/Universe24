"""Exact isolated rest-length-one control, not a coupled physical universe."""
import hashlib
import json
from pathlib import Path

from universe24.core import Engine, NetworkLayout
from universe24.system.bundle import create_bundle
from universe24.system.decoder import default_protocol
from universe24.system.runtime import run_bundle, verify_run
from validation.system_smoke import scalar_step


def run():
    out = Path(__file__).with_name('spring-rest-control')
    layout = NetworkLayout(link_fields=('length',))
    terms = []
    for axis in range(3):
        target = layout.link_name(axis, 'length')
        terms.extend(((target, 3, ()), (target, 3, (layout.link_read(2 * axis, 'length'),))))
    tensor = layout.tensor(terms)
    engine = Engine(tensor)
    cases = []
    for initial in (1, 2, 3):
        seed = layout.uniform_state(3, nodes={}, links={'length': ((1, 1, 1),) * 3})
        seed.b[0, 0] = initial
        bundle = create_bundle(tensor, seed, channels=layout.manifest(), protocol=default_protocol(),
                               model={'id': 'isolated-spring-rest-one-control', 'version': '1',
                                      'domain': 'Signed integer control: u=3b+3; no positivity, spacetime or coupled-node claim'})
        destination = out / f'initial{initial}'
        saved = run_bundle(bundle, destination, 6)
        assert saved == verify_run(destination)
        current = seed
        sequence = [int(seed.b[0, 0])]
        for _ in range(6):
            following = engine.step(current)
            assert following.same_as(scalar_step(tensor, current))
            assert engine.inverse_step(following).same_as(current)
            assert int(following.b[0, 0]) == int(current.b[0, 0]) + 1 - int(current.a[0, 0])
            sequence.append(int(following.b[0, 0]))
            current = following
        assert engine.rewind(current, 6).same_as(seed)
        cases.append({'old_length': 1, 'initial_current_length': initial,
                      'current_lengths': sequence,
                      'strict_positive_lengths': all(v >= 1 for v in sequence),
                      'nonnegative_lengths': all(v >= 0 for v in sequence),
                      'run_id': saved['run_id'], 'tensor_hash': tensor.fingerprint})
    result = {'equation': 'L_next - 2*L + L_previous = -(L-1)',
              'tensor_input': 'u=3*b+3', 'channels': tensor.G,
              'cases': cases,
              'conclusion': 'Rest length one is an exact fixed point, but an ordinary reversible linear spring does not guarantee positive lengths under stretching.',
              'scope': 'Isolated link oscillator control only; no endpoint force coupling, signal delay, stress source or Einstein acceptance.',
              'audit_source_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
    (out / 'results.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    run()
