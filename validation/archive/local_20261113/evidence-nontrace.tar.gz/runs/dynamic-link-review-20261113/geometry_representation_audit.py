"""Exact passive geometry comparison; not a new evolution or neighbor stencil."""
import hashlib
import json
from pathlib import Path

import sympy as sp
from universe24.observe.simplex_metric import signed_intervals, metric_from_intervals, inertia


if __name__ == '__main__':
    orthogonal = sp.eye(3)
    sheared = sp.Matrix([[1, sp.Rational(1, 2), 0], [sp.Rational(1, 2), 1, 0], [0, 0, 1]])
    directions = [sign * sp.eye(3)[:, axis] for axis in range(3) for sign in (1, -1)]
    rows = []
    for name, spatial in (('orthogonal', orthogonal), ('sheared', sheared)):
        metric = sp.diag(-1, 1, 1, 1)
        metric[1:, 1:] = spatial
        intervals = signed_intervals(metric)
        recovered = metric_from_intervals(intervals)
        assert recovered == metric and inertia(recovered) == (1, 3, 0)
        diagonal = sp.Matrix([1, 1, 0])
        rows.append({'name': name, 'spatial_metric': [[str(v) for v in spatial.row(i)] for i in range(3)],
                     'six_face_squared_lengths': [str((d.T * spatial * d)[0]) for d in directions],
                     'xy_cosine': str(spatial[0, 1]),
                     'xy_diagonal_squared_length': str((diagonal.T * spatial * diagonal)[0]),
                     'ten_signed_tangent_intervals': {f'{i}-{j}': str(v) for (i, j), v in intervals.items()},
                     'exact_lorentzian_metric_roundtrip': recovered == metric})
    assert rows[0]['six_face_squared_lengths'] == rows[1]['six_face_squared_lengths']
    assert rows[0]['xy_diagonal_squared_length'] != rows[1]['xy_diagonal_squared_length']
    result = {'cases': rows,
              'six_scalar_face_lengths_determine_general_metric': 'failed',
              'ten_signed_intervals_and_basis_determine_local_metric': 'passed',
              'scope': 'Constant flat metrics in different cell shapes relative to labeled coordinate directions; this is not evidence of curvature. Intervals are tangent-simplex observables, not extra retained physical links or a Regge solver.',
              'audit_source_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
    Path(__file__).with_name('geometry_representation.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result, indent=2))
